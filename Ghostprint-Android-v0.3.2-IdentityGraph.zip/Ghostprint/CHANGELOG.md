# Changelog

## 0.3.0
- Added typed `DataPoint` model with exact returned values, sources, evidence, confidence and candidate status.
- Added Extracted Data tab with full source-backed values.
- Added interactive Identity Graph with query, identity, account, contact, location, breach and source nodes.
- Added direct GitHub and Reddit public-profile field extraction.
- Expanded Gravatar field extraction.
- Expanded HIBP output to include breach metadata and all returned exposed-data categories.
- Added optional Brave Search API support for actual web-result titles, snippets and original URLs.
- Added conservative e-mail, phone, German address and postal-location candidate extraction from public search snippets.
- Added source-backed / verify distinction and “This is mine / Not mine” review controls.
- Added extracted values to AI scan context and shared reports.
- Bumped Android app version to 0.3.0.

## 0.2.0
- Deep Scan, 18 username platforms, exposure dashboard, encrypted settings/history, screenshot shield and AI backend integration.

## 0.3.2
- Fixed Compose scope-extension imports for `weight` and `matchParentSize` that broke Kotlin compilation in GitHub Actions.
