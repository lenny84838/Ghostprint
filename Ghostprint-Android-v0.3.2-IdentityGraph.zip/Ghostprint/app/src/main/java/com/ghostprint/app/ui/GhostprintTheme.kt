package com.ghostprint.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF05070D)
val Surface = Color(0xFF0B1019)
val Surface2 = Color(0xFF111827)
val Surface3 = Color(0xFF172033)
val Cyan = Color(0xFF54E6FF)
val CyanDeep = Color(0xFF0DA7D4)
val Violet = Color(0xFF9B7BFF)
val TextPrimary = Color(0xFFF7F9FF)
val TextMuted = Color(0xFF96A2B8)
val TextFaint = Color(0xFF66738B)
val Good = Color(0xFF68E6B6)
val Warning = Color(0xFFFFC970)
val Danger = Color(0xFFFF6F8D)

private val GhostColors = darkColorScheme(
    primary = Cyan,
    secondary = Violet,
    background = Bg,
    surface = Surface,
    surfaceVariant = Surface2,
    onPrimary = Color(0xFF001319),
    onSecondary = TextPrimary,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextMuted,
    error = Danger
)

@Composable
fun GhostprintTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = GhostColors, content = content)
}
