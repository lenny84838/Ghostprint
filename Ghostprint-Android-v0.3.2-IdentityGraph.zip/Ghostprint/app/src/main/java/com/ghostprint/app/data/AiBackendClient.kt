package com.ghostprint.app.data

import java.net.HttpURLConnection
import java.net.URI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class AiBackendClient {
    suspend fun send(
        backendUrl: String,
        appToken: String,
        messages: List<ChatMessage>,
        context: String = ""
    ): String = withContext(Dispatchers.IO) {
        require(backendUrl.startsWith("https://")) { "Use an HTTPS backend URL." }
        val url = backendUrl.trimEnd('/') + "/chat"
        val connection = URI(url).toURL().openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.connectTimeout = 12000
        connection.readTimeout = 70000
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json")
        connection.setRequestProperty("Accept", "application/json")
        if (appToken.isNotBlank()) connection.setRequestProperty("Authorization", "Bearer $appToken")

        val history = JSONArray()
        messages.takeLast(20).forEach {
            history.put(JSONObject().put("role", it.role).put("text", it.text.take(12000)))
        }
        val body = JSONObject()
            .put("history", history)
            .put("context", context.take(24000))
            .toString()

        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        connection.disconnect()

        if (code !in 200..299) {
            val detail = runCatching { JSONObject(response).optString("error") }.getOrDefault("")
            error(if (detail.isBlank()) "AI backend returned HTTP $code" else detail)
        }
        JSONObject(response).optString("text").ifBlank { "No response text returned." }
    }
}
