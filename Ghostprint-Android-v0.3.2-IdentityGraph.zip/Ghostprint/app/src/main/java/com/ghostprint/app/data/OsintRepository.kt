package com.ghostprint.app.data

import java.net.HttpURLConnection
import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup

class OsintRepository {

    suspend fun scan(
        input: String,
        hibpApiKey: String,
        braveApiKey: String = "",
        deepScan: Boolean = true
    ): ScanReport = withContext(Dispatchers.IO) {
        val clean = input.trim()
        require(clean.length in 2..250) { "Please enter a valid identifier." }
        val type = detectQueryType(clean)
        val bundle = when (type) {
            QueryType.EMAIL -> emailScan(clean, hibpApiKey, braveApiKey, deepScan)
            QueryType.USERNAME -> usernameScan(clean.removePrefix("@"), braveApiKey, deepScan)
            QueryType.PHONE -> phoneScan(clean, braveApiKey, deepScan)
            QueryType.FULL_NAME -> nameScan(clean, braveApiKey, deepScan)
            QueryType.URL -> urlScan(clean)
            QueryType.UNKNOWN -> genericScan(clean, braveApiKey, deepScan)
        }

        val points = dedupeData(bundle.dataPoints)
        val findings = bundle.findings
        val score = calculateExposure(findings, points)
        val exposure = when {
            score >= 70 -> "HIGH"
            score >= 40 -> "MEDIUM"
            score >= 15 -> "LOW"
            else -> "MINIMAL"
        }

        ScanReport(
            query = clean,
            type = type,
            findings = findings,
            dataPoints = points,
            graph = buildGraph(clean, type, points),
            exposureLabel = exposure,
            exposureScore = score,
            scannedSources = (findings.map { it.source } + points.map { it.source }).distinct().size
        )
    }

    private fun calculateExposure(findings: List<Finding>, points: List<DataPoint>): Int {
        var score = 0
        findings.forEach { finding ->
            score += when {
                finding.category == FindingCategory.BREACH && finding.level == FindingLevel.HIGH -> 24
                finding.category == FindingCategory.BREACH && finding.state == FindingState.FOUND -> 14
                finding.state == FindingState.FOUND && finding.level == FindingLevel.MEDIUM -> 8
                finding.state == FindingState.FOUND -> 4
                else -> 0
            }
        }
        score += points.count { it.sensitive && !it.candidate } * 7
        score += points.count { it.type == DataType.ADDRESS && it.candidate } * 3
        return score.coerceIn(0, 100)
    }

    private suspend fun usernameScan(username: String, braveKey: String, deep: Boolean): ScanBundle {
        val platforms = mutableListOf(
            Platform("GitHub", "https://github.com/$username", "https://api.github.com/users/$username"),
            Platform("Reddit", "https://www.reddit.com/user/$username", "https://www.reddit.com/user/$username/about.json"),
            Platform("TikTok", "https://www.tiktok.com/@$username"),
            Platform("Instagram", "https://www.instagram.com/$username/"),
            Platform("Twitch", "https://www.twitch.tv/$username"),
            Platform("YouTube", "https://www.youtube.com/@$username"),
            Platform("Threads", "https://www.threads.net/@$username"),
            Platform("GitLab", "https://gitlab.com/$username"),
            Platform("DEV", "https://dev.to/$username"),
            Platform("Codeberg", "https://codeberg.org/$username")
        )
        if (deep) platforms += listOf(
            Platform("Medium", "https://medium.com/@$username"),
            Platform("Pinterest", "https://www.pinterest.com/$username/"),
            Platform("SoundCloud", "https://soundcloud.com/$username"),
            Platform("Steam", "https://steamcommunity.com/id/$username"),
            Platform("Docker Hub", "https://hub.docker.com/u/$username"),
            Platform("Hacker News", "https://news.ycombinator.com/user?id=$username"),
            Platform("Keybase", "https://keybase.io/$username"),
            Platform("Replit", "https://replit.com/@$username")
        )

        val findings = coroutineScope { platforms.map { p -> async { platformFinding(username, p) } }.awaitAll() }.toMutableList()
        val points = mutableListOf(seedPoint(DataType.USERNAME, "Searched username", "@$username", true))

        githubProfile(username)?.let { points.addAll(it) }
        redditProfile(username)?.let { points.addAll(it) }

        findings.filter { it.state == FindingState.FOUND && it.url != null }
            .take(if (deep) 12 else 6)
            .forEach { finding -> points.addAll(profileMetadata(finding.source, finding.url!!, username)) }

        val web = braveSearchExact("\"$username\"", braveKey, if (deep) 20 else 10)
        points.addAll(web.flatMap { webHitToPoints(it, username) })
        if (braveKey.isBlank()) findings += searchProviderNotice(username)
        else findings += web.map { hit -> webHitFinding(hit) }

        return ScanBundle(findings, points)
    }

    private fun platformFinding(username: String, platform: Platform): Finding {
        val status = probe(platform.probeUrl ?: platform.profileUrl)
        return when (status) {
            200 -> Finding(
                title = "Public account endpoint responded",
                subtitle = "@$username",
                source = platform.name,
                url = platform.profileUrl,
                level = FindingLevel.MEDIUM,
                category = FindingCategory.ACCOUNT,
                state = FindingState.FOUND,
                confidence = if (platform.probeUrl != null) 92 else 72,
                detail = "Ghostprint found a public profile endpoint for this exact username. Use the displayed source data to confirm it is yours.",
                evidence = listOf("Exact username path", "HTTP 200 from public endpoint")
            )
            404, 410 -> Finding(
                title = "No public account detected",
                subtitle = "@$username",
                source = platform.name,
                url = platform.profileUrl,
                level = FindingLevel.INFO,
                category = FindingCategory.ACCOUNT,
                state = FindingState.NOT_FOUND,
                confidence = 78,
                detail = "The public endpoint returned HTTP $status."
            )
            401, 403, 429 -> Finding(
                title = "Manual verification needed",
                subtitle = "@$username",
                source = platform.name,
                url = platform.profileUrl,
                level = FindingLevel.LOW,
                category = FindingCategory.ACCOUNT,
                state = FindingState.MANUAL,
                confidence = 35,
                detail = "The service blocked or rate-limited automated verification (HTTP $status)."
            )
            else -> Finding(
                title = "Check source manually",
                subtitle = "@$username",
                source = platform.name,
                url = platform.profileUrl,
                level = FindingLevel.LOW,
                category = FindingCategory.ACCOUNT,
                state = FindingState.MANUAL,
                confidence = 20,
                detail = "Automated verification was inconclusive (HTTP $status)."
            )
        }
    }

    private fun githubProfile(username: String): List<DataPoint>? = runCatching {
        val (code, body) = getText("https://api.github.com/users/${encodePath(username)}", mapOf("Accept" to "application/vnd.github+json"))
        if (code != 200) return@runCatching emptyList()
        val j = JSONObject(body)
        buildList {
            add(point(DataType.PROFILE, "GitHub profile", j.optString("html_url"), "GitHub", j.optString("html_url"), 98, "GitHub public users API"))
            addIf(this, DataType.USERNAME, "GitHub username", j.optString("login"), "GitHub", j.optString("html_url"), 100)
            addIf(this, DataType.FULL_NAME, "Display name", j.optString("name"), "GitHub", j.optString("html_url"), 94)
            addIf(this, DataType.BIO, "Bio", j.optString("bio"), "GitHub", j.optString("html_url"), 90)
            addIf(this, DataType.COMPANY, "Company", j.optString("company"), "GitHub", j.optString("html_url"), 90)
            addIf(this, DataType.LOCATION, "Location", j.optString("location"), "GitHub", j.optString("html_url"), 90, sensitive = true)
            addIf(this, DataType.WEBSITE, "Website", j.optString("blog"), "GitHub", j.optString("html_url"), 88)
            addIf(this, DataType.USERNAME, "X / Twitter username", j.optString("twitter_username"), "GitHub", j.optString("html_url"), 88)
            addIf(this, DataType.DATE, "GitHub account created", j.optString("created_at"), "GitHub", j.optString("html_url"), 98)
            addIf(this, DataType.METRIC, "Public repositories", j.optInt("public_repos", -1).takeIf { it >= 0 }?.toString().orEmpty(), "GitHub", j.optString("html_url"), 98)
            addIf(this, DataType.METRIC, "Followers", j.optInt("followers", -1).takeIf { it >= 0 }?.toString().orEmpty(), "GitHub", j.optString("html_url"), 98)
        }
    }.getOrNull()

    private fun redditProfile(username: String): List<DataPoint>? = runCatching {
        val url = "https://www.reddit.com/user/${encodePath(username)}/about.json"
        val (code, body) = getText(url)
        if (code != 200) return@runCatching emptyList()
        val data = JSONObject(body).optJSONObject("data") ?: return@runCatching emptyList()
        val profileUrl = "https://www.reddit.com/user/$username"
        buildList {
            add(point(DataType.PROFILE, "Reddit profile", profileUrl, "Reddit", profileUrl, 96, "Reddit public profile API"))
            addIf(this, DataType.USERNAME, "Reddit username", data.optString("name"), "Reddit", profileUrl, 100)
            addIf(this, DataType.METRIC, "Comment karma", data.optLong("comment_karma", -1).takeIf { it >= 0 }?.toString().orEmpty(), "Reddit", profileUrl, 96)
            addIf(this, DataType.METRIC, "Post karma", data.optLong("link_karma", -1).takeIf { it >= 0 }?.toString().orEmpty(), "Reddit", profileUrl, 96)
            val sub = data.optJSONObject("subreddit")
            addIf(this, DataType.FULL_NAME, "Display name", sub?.optString("title").orEmpty(), "Reddit", profileUrl, 72, candidate = true)
            addIf(this, DataType.BIO, "Public profile description", sub?.optString("public_description").orEmpty(), "Reddit", profileUrl, 82)
        }
    }.getOrNull()

    private fun profileMetadata(source: String, url: String, expectedUsername: String): List<DataPoint> = runCatching {
        val (code, html) = getText(url)
        if (code !in 200..299 || html.isBlank()) return@runCatching emptyList()
        val doc = Jsoup.parse(html, url)
        val title = doc.selectFirst("meta[property=og:title]")?.attr("content")?.trim().orEmpty().ifBlank { doc.title().trim() }
        val description = doc.selectFirst("meta[property=og:description]")?.attr("content")?.trim().orEmpty()
            .ifBlank { doc.selectFirst("meta[name=description]")?.attr("content")?.trim().orEmpty() }
        buildList {
            if (title.isNotBlank()) add(point(DataType.FULL_NAME, "$source profile title", title.take(240), source, url, 66, "Public page metadata; confirm identity", candidate = true))
            if (description.isNotBlank()) add(point(DataType.BIO, "$source public description", description.take(600), source, url, 66, "Public page metadata; exact username path @$expectedUsername", candidate = true))
        }
    }.getOrDefault(emptyList())

    private fun emailScan(email: String, hibpKey: String, braveKey: String, deep: Boolean): ScanBundle {
        val findings = mutableListOf<Finding>()
        val points = mutableListOf(seedPoint(DataType.EMAIL, "Searched e-mail", email, true, sensitive = true))

        val gravatar = gravatarProfile(email)
        if (gravatar.isNotEmpty()) {
            findings += Finding(
                title = "Public Gravatar data found",
                subtitle = email,
                source = "Gravatar",
                url = gravatar.firstOrNull()?.sourceUrl,
                level = FindingLevel.MEDIUM,
                category = FindingCategory.IDENTITY,
                state = FindingState.FOUND,
                confidence = 95,
                detail = "Ghostprint extracted the public fields below instead of only marking this as found."
            )
            points.addAll(gravatar)
        } else {
            findings += Finding("No public Gravatar profile detected", email, "Gravatar", "https://gravatar.com/", FindingLevel.INFO, FindingCategory.IDENTITY, FindingState.NOT_FOUND, 80)
        }

        if (hibpKey.isBlank()) {
            findings += Finding(
                "Breach lookup not configured",
                "Add a Have I Been Pwned API key in Settings",
                "Have I Been Pwned",
                "https://haveibeenpwned.com/API/Key",
                FindingLevel.INFO,
                FindingCategory.BREACH,
                FindingState.INFO,
                100,
                "HIBP does not provide plaintext passwords. Ghostprint displays breach metadata and the exact categories of data reported as exposed."
            )
        } else {
            val breach = hibpBreaches(email, hibpKey)
            findings += breach.findings
            points.addAll(breach.dataPoints)
        }

        val web = braveSearchExact("\"$email\"", braveKey, if (deep) 20 else 10)
        points.addAll(web.flatMap { webHitToPoints(it, email) })
        if (braveKey.isBlank()) findings += searchProviderNotice(email)
        else findings += web.map { webHitFinding(it) }

        findings += searchLink("GitHub e-mail mentions", "Open GitHub code search for this exact address", "GitHub", "https://github.com/search?q=${encode("\"$email\"")}&type=code", FindingCategory.WEB)
        return ScanBundle(findings, points)
    }

    private fun gravatarProfile(email: String): List<DataPoint> = runCatching {
        val hash = md5(email.trim().lowercase()).lowercase()
        val (code, body) = getText("https://www.gravatar.com/$hash.json")
        if (code != 200) return@runCatching emptyList()
        val entry = JSONObject(body).optJSONArray("entry")?.optJSONObject(0) ?: return@runCatching emptyList()
        val profileUrl = entry.optString("profileUrl", "https://gravatar.com/$hash")
        buildList {
            add(point(DataType.PROFILE, "Gravatar profile", profileUrl, "Gravatar", profileUrl, 98, "Public Gravatar profile"))
            addIf(this, DataType.FULL_NAME, "Display name", entry.optString("displayName"), "Gravatar", profileUrl, 95)
            addIf(this, DataType.USERNAME, "Preferred username", entry.optString("preferredUsername"), "Gravatar", profileUrl, 95)
            addIf(this, DataType.LOCATION, "Current location", entry.optString("currentLocation"), "Gravatar", profileUrl, 92, sensitive = true)
            addIf(this, DataType.BIO, "About", entry.optString("aboutMe"), "Gravatar", profileUrl, 92)
            entry.optJSONArray("urls")?.let { urls ->
                for (i in 0 until urls.length()) {
                    val u = urls.optJSONObject(i) ?: continue
                    addIf(this, DataType.WEBSITE, u.optString("title", "Website"), u.optString("value"), "Gravatar", profileUrl, 90)
                }
            }
        }
    }.getOrDefault(emptyList())

    private fun hibpBreaches(email: String, apiKey: String): ScanBundle {
        val encoded = URLEncoder.encode(email, StandardCharsets.UTF_8.toString())
        val connection = open("https://haveibeenpwned.com/api/v3/breachedaccount/$encoded?truncateResponse=false")
        connection.setRequestProperty("hibp-api-key", apiKey)
        connection.setRequestProperty("user-agent", "Ghostprint-Self-Audit/0.3")
        val code = connection.responseCode
        if (code == 404) {
            connection.disconnect()
            return ScanBundle(listOf(Finding("No HIBP breach returned", email, "Have I Been Pwned", "https://haveibeenpwned.com/", FindingLevel.INFO, FindingCategory.BREACH, FindingState.NOT_FOUND, 100)), emptyList())
        }
        if (code != 200) {
            connection.disconnect()
            return ScanBundle(listOf(Finding("HIBP lookup unavailable", "HTTP $code", "Have I Been Pwned", "https://haveibeenpwned.com/", FindingLevel.INFO, FindingCategory.BREACH, FindingState.INFO, 100)), emptyList())
        }
        val body = connection.inputStream.bufferedReader().use { it.readText() }
        connection.disconnect()
        val array = JSONArray(body)
        val findings = mutableListOf<Finding>()
        val points = mutableListOf<DataPoint>()
        for (i in 0 until array.length()) {
            val b = array.getJSONObject(i)
            val name = b.optString("Title", b.optString("Name", "Breach"))
            val domain = b.optString("Domain")
            val breachUrl = if (domain.isNotBlank()) "https://$domain" else "https://haveibeenpwned.com/"
            val classes = b.optJSONArray("DataClasses")
            val dataTypes = buildList<String> { if (classes != null) for (j in 0 until classes.length()) add(classes.optString(j)) }
            val passwordRelated = dataTypes.any { it.contains("Password", true) }
            val verified = b.optBoolean("IsVerified", false)
            findings += Finding(
                title = name,
                subtitle = "${b.optString("BreachDate", "Unknown date")} · ${dataTypes.joinToString(", ")}",
                source = "Have I Been Pwned",
                url = breachUrl,
                level = if (passwordRelated) FindingLevel.HIGH else FindingLevel.MEDIUM,
                category = FindingCategory.BREACH,
                state = FindingState.FOUND,
                confidence = if (verified) 100 else 90,
                detail = "HIBP reports which categories of data were present in the breach. It does not expose the stolen field values or plaintext passwords.",
                evidence = listOfNotNull(
                    "Breach: $name",
                    b.optString("BreachDate").takeIf { it.isNotBlank() }?.let { "Breach date: $it" },
                    b.optLong("PwnCount", -1).takeIf { it >= 0 }?.let { "Affected accounts reported: $it" },
                    if (verified) "HIBP: verified breach" else null
                )
            )
            points += point(DataType.BREACH, "Breach", name, "Have I Been Pwned", breachUrl, if (verified) 100 else 90, "Account: $email", sensitive = true)
            addIf(points, DataType.DATE, "$name breach date", b.optString("BreachDate"), "Have I Been Pwned", breachUrl, 100)
            addIf(points, DataType.DATE, "$name added to HIBP", b.optString("AddedDate"), "Have I Been Pwned", breachUrl, 100)
            addIf(points, DataType.METRIC, "$name affected accounts", b.optLong("PwnCount", -1).takeIf { it >= 0 }?.toString().orEmpty(), "Have I Been Pwned", breachUrl, 100)
            dataTypes.forEach { dataType ->
                points += point(DataType.BREACH_DATA, "$name exposed data type", dataType, "Have I Been Pwned", breachUrl, if (verified) 100 else 90, "HIBP DataClasses", sensitive = true)
            }
        }
        return ScanBundle(findings, points)
    }

    private fun nameScan(name: String, braveKey: String, deep: Boolean): ScanBundle {
        val points = mutableListOf(seedPoint(DataType.FULL_NAME, "Searched name", name, true))
        val findings = mutableListOf<Finding>()
        val web = braveSearchExact("\"$name\"", braveKey, if (deep) 25 else 12)
        points.addAll(web.flatMap { webHitToPoints(it, name) })
        if (braveKey.isBlank()) {
            findings += searchProviderNotice(name)
            findings += manualSearchSet(name)
        } else findings += web.map { webHitFinding(it) }
        return ScanBundle(findings, points)
    }

    private fun phoneScan(phone: String, braveKey: String, deep: Boolean): ScanBundle {
        val normalized = phone.replace(Regex("[^+0-9]"), "")
        val points = mutableListOf(seedPoint(DataType.PHONE, "Searched phone number", normalized, true, sensitive = true))
        val findings = mutableListOf<Finding>()
        val web = braveSearchExact("\"$normalized\"", braveKey, if (deep) 20 else 10)
        points.addAll(web.flatMap { webHitToPoints(it, normalized) })
        if (braveKey.isBlank()) {
            findings += searchProviderNotice(normalized)
            findings += manualSearchSet(normalized)
        } else findings += web.map { webHitFinding(it) }
        return ScanBundle(findings, points)
    }

    private fun urlScan(url: String): ScanBundle {
        val findings = mutableListOf(
            Finding("Direct source", url, "Direct URL", url, FindingLevel.INFO, FindingCategory.SOURCE, FindingState.INFO, 100, "Ghostprint extracts only data visible on the supplied public page.")
        )
        val points = mutableListOf(seedPoint(DataType.WEBSITE, "Supplied URL", url, true))
        runCatching {
            val (code, html) = getText(url)
            if (code in 200..299) {
                val doc = Jsoup.parse(html, url)
                addIf(points, DataType.OTHER, "Page title", doc.title(), hostOf(url), url, 100)
                val desc = doc.selectFirst("meta[name=description]")?.attr("content").orEmpty().ifBlank { doc.selectFirst("meta[property=og:description]")?.attr("content").orEmpty() }
                addIf(points, DataType.BIO, "Page description", desc, hostOf(url), url, 90, candidate = true)
                points.addAll(extractStructuredCandidates(doc.text().take(12_000), hostOf(url), url, url))
            }
        }
        return ScanBundle(findings, points)
    }

    private fun genericScan(query: String, braveKey: String, deep: Boolean): ScanBundle {
        val points = mutableListOf(seedPoint(DataType.OTHER, "Searched value", query, true))
        val findings = mutableListOf<Finding>()
        val web = braveSearchExact("\"$query\"", braveKey, if (deep) 20 else 10)
        points.addAll(web.flatMap { webHitToPoints(it, query) })
        if (braveKey.isBlank()) findings += searchProviderNotice(query) else findings += web.map { webHitFinding(it) }
        return ScanBundle(findings, points)
    }

    private fun braveSearchExact(query: String, apiKey: String, count: Int): List<WebHit> {
        if (apiKey.isBlank()) return emptyList()
        return runCatching {
            val url = "https://api.search.brave.com/res/v1/web/search?q=${encode(query)}&count=${count.coerceIn(1, 20)}&safesearch=moderate"
            val (code, body) = getText(url, mapOf("Accept" to "application/json", "X-Subscription-Token" to apiKey))
            if (code != 200) return@runCatching emptyList()
            val results = JSONObject(body).optJSONObject("web")?.optJSONArray("results") ?: return@runCatching emptyList()
            buildList {
                for (i in 0 until results.length()) {
                    val r = results.optJSONObject(i) ?: continue
                    val u = r.optString("url")
                    if (u.isBlank()) continue
                    add(WebHit(r.optString("title").stripHtml(), u, r.optString("description").stripHtml()))
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun webHitToPoints(hit: WebHit, seed: String): List<DataPoint> {
        val source = hostOf(hit.url)
        val evidence = listOf(hit.title, hit.description).filter { it.isNotBlank() }.joinToString(" · ").take(900)
        return buildList {
            add(point(DataType.WEB_MENTION, "Web result", hit.title.ifBlank { hit.url }, source, hit.url, 62, evidence, candidate = true))
            addAll(extractStructuredCandidates("${hit.title}\n${hit.description}", source, hit.url, seed))
        }
    }

    private fun extractStructuredCandidates(text: String, source: String, sourceUrl: String, seed: String): List<DataPoint> {
        val out = mutableListOf<DataPoint>()
        val clean = text.replace(Regex("\\s+"), " ").trim()
        val context = clean.take(700)

        EMAIL_REGEX.findAll(clean).map { it.value }.distinct().take(8).forEach {
            out += point(DataType.EMAIL, "E-mail candidate", it, source, sourceUrl, if (it.equals(seed, true)) 95 else 55, context, sensitive = true, candidate = !it.equals(seed, true))
        }
        PHONE_REGEX.findAll(clean).map { it.value.trim() }.distinct().take(8).forEach {
            val normalized = it.replace(Regex("\\s+"), " ")
            out += point(DataType.PHONE, "Phone candidate", normalized, source, sourceUrl, 52, context, sensitive = true, candidate = true)
        }
        ADDRESS_REGEX.findAll(clean).map { it.value.trim() }.distinct().take(6).forEach {
            out += point(DataType.ADDRESS, "Address candidate", it, source, sourceUrl, 48, context, sensitive = true, candidate = true)
        }
        POSTAL_CITY_REGEX.findAll(clean).map { it.value.trim() }.distinct().take(6).forEach {
            out += point(DataType.LOCATION, "Location candidate", it, source, sourceUrl, 45, context, sensitive = true, candidate = true)
        }
        return out
    }

    private fun webHitFinding(hit: WebHit): Finding = Finding(
        title = hit.title.ifBlank { "Public web result" },
        subtitle = hit.description.take(220),
        source = hostOf(hit.url),
        url = hit.url,
        level = FindingLevel.LOW,
        category = FindingCategory.WEB,
        state = FindingState.FOUND,
        confidence = 62,
        detail = "Search result returned by the configured public web-search provider. Open the original page to verify context.",
        evidence = listOfNotNull(hit.description.takeIf { it.isNotBlank() })
    )

    private fun searchProviderNotice(value: String): Finding = Finding(
        title = "Web extraction not configured",
        subtitle = "Add a Brave Search API key in Settings to return actual web-result titles, snippets and source URLs inside Ghostprint.",
        source = "Ghostprint",
        url = "https://api.search.brave.com/",
        level = FindingLevel.INFO,
        category = FindingCategory.WEB,
        state = FindingState.INFO,
        confidence = 100,
        detail = "Without a search API Ghostprint will not pretend a search link is a discovered fact. Manual search links are still available for: $value"
    )

    private fun manualSearchSet(value: String): List<Finding> = listOf(
        searchLink("Google exact search", "Manual fallback", "Google", "https://www.google.com/search?q=${quoteQuery(value)}", FindingCategory.WEB),
        searchLink("DuckDuckGo exact search", "Manual fallback", "DuckDuckGo", "https://duckduckgo.com/?q=${quoteQuery(value)}", FindingCategory.WEB),
        searchLink("Bing exact search", "Manual fallback", "Bing", "https://www.bing.com/search?q=${quoteQuery(value)}", FindingCategory.WEB)
    )

    suspend fun checkPassword(password: String): Int = withContext(Dispatchers.IO) {
        require(password.isNotEmpty()) { "Password is empty." }
        val hash = sha1(password)
        val prefix = hash.take(5)
        val suffix = hash.drop(5)
        val connection = open("https://api.pwnedpasswords.com/range/$prefix")
        connection.setRequestProperty("Add-Padding", "true")
        connection.setRequestProperty("user-agent", "Ghostprint-Self-Audit/0.3")
        val code = connection.responseCode
        if (code != 200) {
            connection.disconnect()
            error("Pwned Passwords returned HTTP $code")
        }
        val count = connection.inputStream.bufferedReader().useLines { lines ->
            lines.mapNotNull { line ->
                val parts = line.trim().split(":", limit = 2)
                if (parts.size == 2 && parts[0].equals(suffix, true)) parts[1].toIntOrNull() else null
            }.firstOrNull()
        } ?: 0
        connection.disconnect()
        count
    }

    private fun buildGraph(query: String, type: QueryType, points: List<DataPoint>): IdentityGraph {
        val root = GraphNode("query", query.take(42), type.label, GraphNodeType.QUERY, query)
        val nodes = mutableListOf(root)
        val edges = mutableListOf<GraphEdge>()
        val sourceIds = mutableMapOf<String, String>()

        points.forEach { dp ->
            val nodeType = when (dp.type) {
                DataType.EMAIL, DataType.PHONE -> GraphNodeType.CONTACT
                DataType.ADDRESS, DataType.LOCATION -> GraphNodeType.LOCATION
                DataType.BREACH, DataType.BREACH_DATA -> GraphNodeType.BREACH
                DataType.PROFILE, DataType.USERNAME -> GraphNodeType.ACCOUNT
                DataType.WEB_MENTION, DataType.WEBSITE -> GraphNodeType.WEB
                else -> GraphNodeType.IDENTITY
            }
            nodes += GraphNode(dp.id, dp.value.take(42), dp.label, nodeType, dp.value, dp.sourceUrl)
            edges += GraphEdge("query", dp.id, if (dp.candidate) "candidate" else "found", dp.confidence)
            dp.sourceUrl?.let { url ->
                val key = "${dp.source}|$url"
                val sourceId = sourceIds.getOrPut(key) {
                    "src_${shortHash(key)}".also { id -> nodes += GraphNode(id, dp.source.take(30), hostOf(url), GraphNodeType.SOURCE, url, url) }
                }
                edges += GraphEdge(dp.id, sourceId, "source", 100)
            }
        }
        return IdentityGraph(nodes.distinctBy { it.id }, edges.distinctBy { "${it.from}|${it.to}|${it.label}" })
    }

    private fun dedupeData(points: List<DataPoint>): List<DataPoint> = points
        .filter { it.value.isNotBlank() && it.value != "null" }
        .distinctBy { "${it.type}|${it.value.trim().lowercase()}|${it.sourceUrl.orEmpty()}" }

    private fun seedPoint(type: DataType, label: String, value: String, confirmed: Boolean, sensitive: Boolean = false): DataPoint =
        point(type, label, value, "Your input", null, if (confirmed) 100 else 80, "Value entered by you", sensitive)

    private fun point(
        type: DataType,
        label: String,
        value: String,
        source: String,
        sourceUrl: String?,
        confidence: Int,
        evidence: String? = null,
        sensitive: Boolean = false,
        candidate: Boolean = false
    ): DataPoint = DataPoint(
        id = "d_${shortHash("$type|$value|$source|${sourceUrl.orEmpty()}")}",
        type = type,
        label = label,
        value = value.trim(),
        source = source,
        sourceUrl = sourceUrl?.takeIf { it.isNotBlank() },
        confidence = confidence.coerceIn(0, 100),
        evidence = evidence?.takeIf { it.isNotBlank() },
        sensitive = sensitive,
        candidate = candidate
    )

    private fun addIf(
        list: MutableList<DataPoint>,
        type: DataType,
        label: String,
        value: String,
        source: String,
        sourceUrl: String?,
        confidence: Int,
        evidence: String? = null,
        sensitive: Boolean = false,
        candidate: Boolean = false
    ) {
        if (value.isNotBlank() && value != "null") list += point(type, label, value, source, sourceUrl, confidence, evidence, sensitive, candidate)
    }

    private fun searchLink(title: String, subtitle: String, source: String, url: String, category: FindingCategory): Finding = Finding(
        title = title,
        subtitle = subtitle,
        source = source,
        url = url,
        level = FindingLevel.LOW,
        category = category,
        state = FindingState.MANUAL,
        confidence = 20,
        detail = "Manual fallback only. Ghostprint does not count this as discovered data."
    )

    private fun probe(url: String): Int = runCatching {
        val connection = open(url)
        val code = connection.responseCode
        runCatching { (if (code in 200..399) connection.inputStream else connection.errorStream)?.close() }
        connection.disconnect()
        code
    }.getOrDefault(-1)

    private fun getText(url: String, headers: Map<String, String> = emptyMap()): Pair<Int, String> {
        val connection = open(url)
        headers.forEach { (k, v) -> connection.setRequestProperty(k, v) }
        val code = connection.responseCode
        val stream = if (code in 200..399) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        connection.disconnect()
        return code to body
    }

    private fun open(url: String): HttpURLConnection = (URI(url).toURL().openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        instanceFollowRedirects = true
        connectTimeout = 7000
        readTimeout = 7000
        setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Ghostprint/0.3 Self-Audit")
        setRequestProperty("Accept-Language", "en-US,en;q=0.8,de;q=0.6")
    }

    private fun String.stripHtml(): String = Jsoup.parse(this).text()
    private fun quoteQuery(value: String): String = encode("\"$value\"")
    private fun encode(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.toString())
    private fun encodePath(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.toString()).replace("+", "%20")
    private fun hostOf(url: String): String = runCatching { URI(url).host?.removePrefix("www.").orEmpty() }.getOrDefault("").ifBlank { "Web" }
    private fun sha1(value: String): String = digest("SHA-1", value.toByteArray())
    private fun md5(value: String): String = digest("MD5", value.toByteArray())
    private fun shortHash(value: String): String = sha1(value).take(14).lowercase()
    private fun digest(algorithm: String, bytes: ByteArray): String = MessageDigest.getInstance(algorithm).digest(bytes).joinToString("") { "%02X".format(it) }

    private data class Platform(val name: String, val profileUrl: String, val probeUrl: String? = null)
    private data class ScanBundle(val findings: List<Finding>, val dataPoints: List<DataPoint>)
    private data class WebHit(val title: String, val url: String, val description: String)

    companion object {
        private val EMAIL_REGEX = Regex("(?i)\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}\\b")
        private val PHONE_REGEX = Regex("(?<!\\d)(?:\\+?\\d{1,3}[ .\\-/]?)?(?:\\(?\\d{2,5}\\)?[ .\\-/]?)?\\d{3,4}[ .\\-/]?\\d{3,6}(?!\\d)")
        private val ADDRESS_REGEX = Regex("(?i)\\b[A-ZÄÖÜ][A-Za-zÄÖÜäöüß.\\- ]{2,45}(?:straße|str\\.|weg|allee|platz|gasse|ring|ufer|chaussee)\\s+\\d{1,4}[a-zA-Z]?\\b")
        private val POSTAL_CITY_REGEX = Regex("\\b\\d{5}\\s+[A-ZÄÖÜ][A-Za-zÄÖÜäöüß\\- ]{2,40}\\b")
    }
}
