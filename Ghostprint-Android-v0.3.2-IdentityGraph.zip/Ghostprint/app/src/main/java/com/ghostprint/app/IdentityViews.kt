package com.ghostprint.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ghostprint.app.data.DataPoint
import com.ghostprint.app.data.DataType
import com.ghostprint.app.data.GraphNode
import com.ghostprint.app.data.GraphNodeType
import com.ghostprint.app.data.IdentityGraph
import com.ghostprint.app.ui.Cyan
import com.ghostprint.app.ui.Danger
import com.ghostprint.app.ui.Good
import com.ghostprint.app.ui.Surface2
import com.ghostprint.app.ui.Surface3
import com.ghostprint.app.ui.TextFaint
import com.ghostprint.app.ui.TextMuted
import com.ghostprint.app.ui.Violet
import com.ghostprint.app.ui.Warning
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

@Composable
fun DataPointCard(point: DataPoint) {
    val uri = LocalUriHandler.current
    val clipboard = LocalClipboardManager.current
    var expanded by remember(point.id) { mutableStateOf(false) }
    var verdict by remember(point.id) { mutableStateOf<String?>(null) }
    val tint = when {
        point.type == DataType.BREACH || point.type == DataType.BREACH_DATA -> Danger
        point.type == DataType.ADDRESS || point.type == DataType.PHONE || point.type == DataType.EMAIL -> Warning
        point.candidate -> Violet
        else -> Cyan
    }

    Surface(
        shape = RoundedCornerShape(22.dp),
        color = Surface2.copy(alpha = .82f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).background(tint, CircleShape))
                Spacer(Modifier.width(9.dp))
                Text(point.type.label.uppercase(), color = tint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Surface(shape = RoundedCornerShape(999.dp), color = tint.copy(alpha = .12f)) {
                    Text(
                        if (point.candidate) "VERIFY" else "SOURCE-BACKED",
                        color = tint,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
            Spacer(Modifier.height(9.dp))
            Text(point.label, color = TextMuted, fontSize = 12.sp)
            Text(point.value, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Source: ${point.source}", color = TextMuted, fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text("${point.confidence}%", color = TextFaint, fontSize = 11.sp)
            }
            point.evidence?.let { evidence ->
                Spacer(Modifier.height(7.dp))
                TextButton(onClick = { expanded = !expanded }) {
                    Text(if (expanded) "Hide evidence" else "Show evidence")
                }
                if (expanded) Text(evidence, color = TextMuted, fontSize = 12.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { clipboard.setText(AnnotatedString(point.value)) }) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy value", tint = TextMuted)
                }
                point.sourceUrl?.let { url ->
                    TextButton(onClick = { uri.openUri(url) }) {
                        Icon(Icons.Default.Link, contentDescription = null)
                        Spacer(Modifier.width(5.dp))
                        Text("Open original source")
                    }
                }
            }
            if (point.candidate || point.sensitive) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { verdict = "mine" }) { Text("This is mine") }
                    TextButton(onClick = { verdict = "not_mine" }) { Text("Not mine") }
                }
                verdict?.let {
                    Text(
                        if (it == "mine") "Marked as yours for this view." else "Marked as not yours for this view.",
                        color = if (it == "mine") Good else Warning,
                        fontSize = 11.sp
                    )
                }
            }
            if (point.candidate) {
                Text(
                    "Candidate only. Ghostprint found this value near your search term, but it may belong to someone else.",
                    color = TextFaint,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
fun DataSummaryCard(points: List<DataPoint>) {
    val confirmed = points.count { !it.candidate && it.source != "Your input" }
    val candidates = points.count { it.candidate }
    val sensitive = points.count { it.sensitive && it.source != "Your input" }
    Surface(shape = RoundedCornerShape(24.dp), color = Surface2.copy(alpha = .80f), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(17.dp)) {
            Text("Extracted data", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Ghostprint shows the actual values returned by configured public sources, not just ‘something was found’.", color = TextMuted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                GraphMiniStat("Values", points.size.toString(), Modifier.weight(1f))
                GraphMiniStat("Backed", confirmed.toString(), Modifier.weight(1f))
                GraphMiniStat("Verify", candidates.toString(), Modifier.weight(1f))
                GraphMiniStat("Sensitive", sensitive.toString(), Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun GraphMiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(shape = RoundedCornerShape(16.dp), color = Surface3, modifier = modifier) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(label, color = TextMuted, fontSize = 9.sp)
        }
    }
}

@Composable
fun IdentityGraphCard(graph: IdentityGraph) {
    var zoom by remember { mutableFloatStateOf(1f) }
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }
    var selected by remember { mutableStateOf<GraphNode?>(null) }
    val uri = LocalUriHandler.current

    Surface(shape = RoundedCornerShape(26.dp), color = Surface2.copy(alpha = .84f), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Identity Graph", fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Text("Pinch to zoom · drag to move · follow lines back to each source", color = TextMuted, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(520.dp)
                    .background(Surface3.copy(alpha = .55f), RoundedCornerShape(20.dp))
            ) {
                Canvas(
                    modifier = Modifier
                        .matchParentSize()
                        .pointerInput(graph, zoom, panX, panY) {
                            detectTransformGestures { centroid, pan, gestureZoom, _ ->
                                zoom = (zoom * gestureZoom).coerceIn(.45f, 3.2f)
                                panX += pan.x
                                panY += pan.y
                            }
                        }
                        .clickable(enabled = false) {}
                ) {
                    if (graph.nodes.isEmpty()) return@Canvas
                    val center = Offset(size.width / 2f + panX, size.height / 2f + panY)
                    val baseRadius = min(size.width, size.height) * .26f * zoom
                    val sourceRadius = min(size.width, size.height) * .43f * zoom
                    val dataNodes = graph.nodes.filter { it.type != GraphNodeType.QUERY && it.type != GraphNodeType.SOURCE }
                    val sourceNodes = graph.nodes.filter { it.type == GraphNodeType.SOURCE }
                    val positions = mutableMapOf<String, Offset>()
                    graph.nodes.firstOrNull { it.type == GraphNodeType.QUERY }?.let { positions[it.id] = center }

                    dataNodes.forEachIndexed { i, node ->
                        val angle = (2.0 * PI * i / dataNodes.size.coerceAtLeast(1)) - PI / 2
                        positions[node.id] = Offset(
                            center.x + (cos(angle) * baseRadius).toFloat(),
                            center.y + (sin(angle) * baseRadius).toFloat()
                        )
                    }
                    sourceNodes.forEachIndexed { i, node ->
                        val angle = (2.0 * PI * i / sourceNodes.size.coerceAtLeast(1)) - PI / 2
                        positions[node.id] = Offset(
                            center.x + (cos(angle) * sourceRadius).toFloat(),
                            center.y + (sin(angle) * sourceRadius).toFloat()
                        )
                    }

                    graph.edges.forEach { edge ->
                        val a = positions[edge.from] ?: return@forEach
                        val b = positions[edge.to] ?: return@forEach
                        drawLine(Color(0xFF536079).copy(alpha = .46f), a, b, strokeWidth = (1.2f * zoom).coerceAtLeast(.7f))
                    }

                    val paint = android.graphics.Paint().apply {
                        isAntiAlias = true
                        textAlign = android.graphics.Paint.Align.CENTER
                        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                    }

                    graph.nodes.forEach { node ->
                        val pos = positions[node.id] ?: return@forEach
                        val radius = when (node.type) {
                            GraphNodeType.QUERY -> 34f
                            GraphNodeType.SOURCE -> 17f
                            else -> 23f
                        } * zoom
                        val color = nodeColor(node.type)
                        drawCircle(color.copy(alpha = .20f), radius * 1.35f, pos)
                        drawCircle(color, radius, pos)
                        paint.textSize = (10f * zoom).coerceIn(7f, 16f)
                        paint.color = android.graphics.Color.WHITE
                        val short = node.label.replace("\n", " ").take(if (node.type == GraphNodeType.QUERY) 18 else 13)
                        drawContext.canvas.nativeCanvas.drawText(short, pos.x, pos.y + radius + (14f * zoom), paint)
                    }
                }

                Column(Modifier.align(Alignment.TopEnd).padding(10.dp)) {
                    Surface(shape = RoundedCornerShape(999.dp), color = Surface2.copy(alpha = .88f)) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${graph.nodes.size} nodes · ${graph.edges.size} links", color = TextMuted, fontSize = 10.sp)
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            GraphLegend()
            selected?.let { node ->
                Spacer(Modifier.height(8.dp))
                Surface(shape = RoundedCornerShape(16.dp), color = Surface3) {
                    Column(Modifier.padding(12.dp)) {
                        Text(node.label, fontWeight = FontWeight.Bold)
                        Text(node.subtitle, color = TextMuted, fontSize = 12.sp)
                        node.value?.let { Text(it, fontSize = 12.sp) }
                        node.sourceUrl?.let { url -> TextButton(onClick = { uri.openUri(url) }) { Text("Open source") } }
                    }
                }
            }
            Text("The graph visualizes relationships from this scan only. Candidate nodes are evidence to review, not proof of identity.", color = TextFaint, fontSize = 10.sp)
        }
    }
}

@Composable
private fun GraphLegend() {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        LegendDot(Cyan, "Query")
        LegendDot(Violet, "Identity")
        LegendDot(Warning, "Contact")
        LegendDot(Danger, "Breach")
        LegendDot(Good, "Source")
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).background(color, CircleShape))
        Spacer(Modifier.width(4.dp))
        Text(label, color = TextMuted, fontSize = 9.sp)
    }
}

private fun nodeColor(type: GraphNodeType): Color = when (type) {
    GraphNodeType.QUERY -> Cyan
    GraphNodeType.IDENTITY -> Violet
    GraphNodeType.ACCOUNT -> Color(0xFF7C9DFF)
    GraphNodeType.CONTACT -> Warning
    GraphNodeType.LOCATION -> Color(0xFFFFA45B)
    GraphNodeType.BREACH -> Danger
    GraphNodeType.SOURCE -> Good
    GraphNodeType.WEB -> Color(0xFF77D7FF)
}
