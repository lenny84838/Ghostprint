package com.ghostprint.app.data

import java.time.Instant

enum class QueryType(val label: String) {
    EMAIL("E-Mail"),
    PHONE("Telefonnummer"),
    USERNAME("Username"),
    FULL_NAME("Name"),
    URL("URL"),
    UNKNOWN("Suche")
}

enum class FindingLevel { INFO, LOW, MEDIUM, HIGH }
enum class FindingCategory(val label: String) {
    ACCOUNT("Accounts"),
    BREACH("Breaches"),
    WEB("Web"),
    CONTACT("Kontakt"),
    IDENTITY("Identität"),
    SECURITY("Security"),
    SOURCE("Quelle")
}

enum class FindingState { FOUND, NOT_FOUND, MANUAL, INFO }

data class Finding(
    val title: String,
    val subtitle: String,
    val source: String,
    val url: String? = null,
    val level: FindingLevel = FindingLevel.INFO,
    val category: FindingCategory = FindingCategory.SOURCE,
    val state: FindingState = FindingState.INFO,
    val confidence: Int = 0,
    val detail: String? = null,
    val evidence: List<String> = emptyList()
)

enum class DataType(val label: String) {
    FULL_NAME("Name"),
    USERNAME("Username"),
    EMAIL("E-Mail"),
    PHONE("Telefonnummer"),
    ADDRESS("Adresse"),
    LOCATION("Ort"),
    BIO("Bio"),
    COMPANY("Firma / Organisation"),
    WEBSITE("Webseite"),
    PROFILE("Profil"),
    BREACH("Datenleck"),
    BREACH_DATA("Betroffene Datenart"),
    DATE("Datum"),
    METRIC("Öffentliche Kennzahl"),
    WEB_MENTION("Web-Treffer"),
    OTHER("Sonstiges")
}

data class DataPoint(
    val id: String,
    val type: DataType,
    val label: String,
    val value: String,
    val source: String,
    val sourceUrl: String? = null,
    val confidence: Int = 0,
    val evidence: String? = null,
    val sensitive: Boolean = false,
    val candidate: Boolean = false
)

enum class GraphNodeType { QUERY, IDENTITY, ACCOUNT, CONTACT, LOCATION, BREACH, SOURCE, WEB }

data class GraphNode(
    val id: String,
    val label: String,
    val subtitle: String,
    val type: GraphNodeType,
    val value: String? = null,
    val sourceUrl: String? = null
)

data class GraphEdge(
    val from: String,
    val to: String,
    val label: String,
    val confidence: Int = 0
)

data class IdentityGraph(
    val nodes: List<GraphNode> = emptyList(),
    val edges: List<GraphEdge> = emptyList()
)

data class ScanReport(
    val query: String,
    val type: QueryType,
    val findings: List<Finding>,
    val dataPoints: List<DataPoint> = emptyList(),
    val graph: IdentityGraph = IdentityGraph(),
    val exposureLabel: String,
    val exposureScore: Int,
    val scannedSources: Int,
    val generatedAt: String = Instant.now().toString()
)

data class ChatMessage(
    val role: String,
    val text: String
)

data class HistoryEntry(
    val query: String,
    val type: QueryType,
    val exposureLabel: String,
    val exposureScore: Int,
    val timestamp: String
)

fun detectQueryType(raw: String): QueryType {
    val input = raw.trim()
    if (input.startsWith("http://") || input.startsWith("https://")) return QueryType.URL
    if (Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$").matches(input)) return QueryType.EMAIL
    val phone = input.replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
    if (Regex("^\\+?[0-9]{7,15}$").matches(phone)) return QueryType.PHONE
    if (input.contains(" ") && input.split(Regex("\\s+")).size in 2..6) return QueryType.FULL_NAME
    if (Regex("^@?[A-Za-z0-9._-]{2,40}$").matches(input)) return QueryType.USERNAME
    return QueryType.UNKNOWN
}
