package com.ghostprint.app.data

import com.ghostprint.app.security.SecurePrefs
import org.json.JSONArray
import org.json.JSONObject

class HistoryStore(private val prefs: SecurePrefs) {
    private val key = "scan_history_v2"

    fun load(): List<HistoryEntry> {
        val raw = prefs.getSecret(key)
        if (raw.isBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(
                        HistoryEntry(
                            query = o.getString("query"),
                            type = QueryType.valueOf(o.getString("type")),
                            exposureLabel = o.getString("exposureLabel"),
                            exposureScore = o.optInt("exposureScore", 0),
                            timestamp = o.getString("timestamp")
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun add(report: ScanReport) {
        val existing = load().toMutableList()
        existing.removeAll { it.query.equals(report.query, ignoreCase = true) && it.type == report.type }
        existing.add(
            0,
            HistoryEntry(report.query, report.type, report.exposureLabel, report.exposureScore, report.generatedAt)
        )
        save(existing.take(20))
    }

    fun clear() = prefs.remove(key)

    private fun save(entries: List<HistoryEntry>) {
        val arr = JSONArray()
        entries.forEach { e ->
            arr.put(
                JSONObject()
                    .put("query", e.query)
                    .put("type", e.type.name)
                    .put("exposureLabel", e.exposureLabel)
                    .put("exposureScore", e.exposureScore)
                    .put("timestamp", e.timestamp)
            )
        }
        prefs.putSecret(key, arr.toString())
    }
}
