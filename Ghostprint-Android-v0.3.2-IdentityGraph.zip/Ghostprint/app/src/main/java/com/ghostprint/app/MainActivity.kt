package com.ghostprint.app

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ghostprint.app.data.AiBackendClient
import com.ghostprint.app.data.ChatMessage
import com.ghostprint.app.data.Finding
import com.ghostprint.app.data.FindingCategory
import com.ghostprint.app.data.FindingLevel
import com.ghostprint.app.data.FindingState
import com.ghostprint.app.data.HistoryEntry
import com.ghostprint.app.data.HistoryStore
import com.ghostprint.app.data.OsintRepository
import com.ghostprint.app.data.QueryType
import com.ghostprint.app.data.ScanReport
import com.ghostprint.app.data.detectQueryType
import com.ghostprint.app.security.SecurePrefs
import com.ghostprint.app.ui.Bg
import com.ghostprint.app.ui.Cyan
import com.ghostprint.app.ui.Danger
import com.ghostprint.app.ui.GhostprintTheme
import com.ghostprint.app.ui.Good
import com.ghostprint.app.ui.Surface2
import com.ghostprint.app.ui.Surface3
import com.ghostprint.app.ui.TextFaint
import com.ghostprint.app.ui.TextMuted
import com.ghostprint.app.ui.Violet
import com.ghostprint.app.ui.Warning
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = SecurePrefs(this)
        applyScreenShield(prefs.getBoolean("screen_shield", false))
        setContent {
            GhostprintTheme {
                GhostprintApp(onScreenShieldChanged = ::applyScreenShield)
            }
        }
    }

    private fun applyScreenShield(enabled: Boolean) {
        if (enabled) {
            window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }
}

enum class AppTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    SCAN("Scan", Icons.Default.Search),
    HISTORY("History", Icons.Default.History),
    AI("AI", Icons.Default.AutoAwesome),
    SETTINGS("Settings", Icons.Default.Settings)
}

@Composable
fun GhostprintApp(onScreenShieldChanged: (Boolean) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { SecurePrefs(context) }
    val historyStore = remember { HistoryStore(prefs) }
    var tab by rememberSaveable { mutableStateOf(AppTab.HOME) }
    var lastReport by remember { mutableStateOf<ScanReport?>(null) }
    var pendingQuery by rememberSaveable { mutableStateOf("") }
    var history by remember { mutableStateOf(historyStore.load()) }

    fun goToScan(query: String = "") {
        pendingQuery = query
        tab = AppTab.SCAN
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Color(0xF20A0E17)) {
                AppTab.entries.forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                AppTab.HOME -> HomeScreen(
                    history = history,
                    onScan = { goToScan() },
                    onAi = { tab = AppTab.AI }
                )
                AppTab.SCAN -> ScanScreen(
                    initialQuery = pendingQuery,
                    lastReport = lastReport,
                    onReport = { report ->
                        lastReport = report
                        pendingQuery = report.query
                        if (prefs.getBoolean("save_history", false)) {
                            historyStore.add(report)
                            history = historyStore.load()
                        }
                    },
                    onAskAi = { tab = AppTab.AI }
                )
                AppTab.HISTORY -> HistoryScreen(
                    history = history,
                    onRescan = { goToScan(it) },
                    onClear = {
                        historyStore.clear()
                        history = emptyList()
                    }
                )
                AppTab.AI -> AiScreen(lastReport)
                AppTab.SETTINGS -> SettingsScreen(
                    onScreenShieldChanged = onScreenShieldChanged,
                    onHistoryChanged = { history = historyStore.load() }
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(history: List<HistoryEntry>, onScan: () -> Unit, onAi: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(Modifier.height(18.dp)) }
        item { BrandHeader() }
        item { HeroCard(onScan) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                MiniStat("Scans", history.size.toString(), Modifier.weight(1f))
                MiniStat("Private", "Local", Modifier.weight(1f))
                MiniStat("Sources", "18+", Modifier.weight(1f))
            }
        }
        item { SectionTitle("Quick checks", "Jump straight into a focused self-audit") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickCard(Icons.Default.PersonSearch, "Identity scan", "Name or username across public sources", onScan)
                QuickCard(Icons.Default.Email, "Breach check", "E-mail exposure with sourced breach records", onScan)
                QuickCard(Icons.Default.Phone, "Phone footprint", "Exact public mentions and source links", onScan)
                QuickCard(Icons.Default.Key, "Password exposure", "k-anonymity check, never sends the full password", onScan)
                QuickCard(Icons.Default.AutoAwesome, "Ghostprint AI", "Explain findings and build a cleanup plan", onAi)
            }
        }
        item {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Surface2.copy(alpha = .76f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Good)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Evidence-first self-audit", fontWeight = FontWeight.SemiBold)
                        Text("Ghostprint keeps the original source beside every finding and labels uncertain matches instead of inventing certainty.", color = TextMuted, fontSize = 13.sp)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(18.dp)) }
    }
}

@Composable
private fun BrandHeader() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(R.drawable.ghostprint_icon),
            contentDescription = "Ghostprint",
            modifier = Modifier.size(62.dp).clip(RoundedCornerShape(18.dp)),
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.width(14.dp))
        Column {
            Text("Ghostprint", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("Find your public traces. Verify the source.", color = TextMuted, fontSize = 13.sp)
        }
    }
}

@Composable
private fun HeroCard(onScan: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "hero")
    val pulse by transition.animateFloat(
        initialValue = .96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1900), RepeatMode.Reverse),
        label = "pulse"
    )
    Surface(shape = RoundedCornerShape(30.dp), modifier = Modifier.fillMaxWidth(), color = Color.Transparent) {
        Box(
            Modifier
                .background(Brush.linearGradient(listOf(Color(0xFF102B39), Color(0xFF17102E), Color(0xFF0A1822))))
                .padding(22.dp)
        ) {
            Column {
                Box(
                    Modifier.size(60.dp).scale(pulse).clip(CircleShape).background(Cyan.copy(alpha = .13f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Public, contentDescription = null, tint = Cyan, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.height(18.dp))
                Text("Search your digital footprint", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(7.dp))
                Text("One field for your name, @username, e-mail, phone number or URL. Deep Scan expands the public-source coverage.", color = TextMuted)
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = onScan,
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Color(0xFF001319)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Start Deep Scan", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Default.ArrowForward, contentDescription = null)
                }
            }
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(18.dp), color = Surface2.copy(alpha = .72f)) {
        Column(Modifier.padding(14.dp)) {
            Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text(label, color = TextMuted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String? = null) {
    Column {
        Text(title, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
        subtitle?.let { Text(it, color = TextMuted, fontSize = 12.sp) }
    }
}

@Composable
private fun QuickCard(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Surface2.copy(alpha = .72f),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Cyan.copy(alpha = .10f)),
                contentAlignment = Alignment.Center
            ) { Icon(icon, contentDescription = null, tint = Cyan) }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = TextMuted, fontSize = 13.sp)
            }
            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = TextMuted)
        }
    }
}

@Composable
private fun ScanScreen(
    initialQuery: String,
    lastReport: ScanReport?,
    onReport: (ScanReport) -> Unit,
    onAskAi: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { SecurePrefs(context) }
    val repo = remember { OsintRepository() }
    val scope = rememberCoroutineScope()
    var query by rememberSaveable(initialQuery) { mutableStateOf(initialQuery) }
    var authorized by rememberSaveable { mutableStateOf(false) }
    var deepScan by rememberSaveable { mutableStateOf(true) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var report by remember { mutableStateOf(lastReport) }
    var showPassword by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf<FindingCategory?>(null) }
    var resultView by remember { mutableStateOf("DATA") }

    fun launchScan() {
        if (query.isBlank() || loading || !authorized) return
        loading = true
        error = null
        filter = null
        scope.launch {
            runCatching { repo.scan(query, prefs.getSecret("hibp_key"), prefs.getSecret("brave_key"), deepScan) }
                .onSuccess { report = it; onReport(it) }
                .onFailure { error = it.message ?: "Scan failed" }
            loading = false
        }
    }

    if (showPassword) PasswordDialog(repo = repo, onDismiss = { showPassword = false })

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(Modifier.height(18.dp)) }
        item {
            Text("Deep Scan", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("Evidence-first self-audit that extracts the actual public values and keeps every source attached.", color = TextMuted, fontSize = 13.sp)
        }
        item {
            Surface(shape = RoundedCornerShape(24.dp), color = Surface2.copy(alpha = .78f), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Name, @username, e-mail, phone, URL") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { launchScan() }),
                        shape = RoundedCornerShape(18.dp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Surface3,
                            unfocusedContainerColor = Surface3,
                            focusedIndicatorColor = Cyan,
                            unfocusedIndicatorColor = Color.Transparent
                        )
                    )
                    if (query.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text("Detected: ${detectQueryType(query).label}", color = Cyan, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = deepScan, onCheckedChange = { deepScan = it })
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Deep Scan", fontWeight = FontWeight.SemiBold)
                            Text(if (deepScan) "Expanded public-source coverage" else "Faster essential-source scan", color = TextMuted, fontSize = 12.sp)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = authorized, onCheckedChange = { authorized = it })
                        Text("I am checking my own data or data I am authorized to audit.", color = TextMuted, fontSize = 12.sp)
                    }
                    Button(
                        onClick = { launchScan() },
                        enabled = query.isNotBlank() && authorized && !loading,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Color(0xFF001319))
                    ) {
                        if (loading) {
                            CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp, color = Color(0xFF001319))
                            Spacer(Modifier.width(10.dp))
                            Text("Scanning sources…")
                        } else {
                            Icon(Icons.Default.Search, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Scan now", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        item {
            TextButton(onClick = { showPassword = true }) {
                Icon(Icons.Default.Key, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Check one of my passwords")
            }
        }
        if (loading) item { StatusCard("Scanning public sources", "Ghostprint is collecting source-backed values. Blocked services remain VERIFY instead of being guessed, and candidate addresses/contact data are clearly marked.", Cyan) }
        error?.let { message -> item { StatusCard("Scan error", message, Danger) } }
        report?.let { r ->
            item { ExposureHeader(r, onShare = { shareReport(context, r) }) }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { FilterChip(selected = resultView == "DATA", onClick = { resultView = "DATA" }, label = { Text("Extracted data") }) }
                    item { FilterChip(selected = resultView == "GRAPH", onClick = { resultView = "GRAPH" }, label = { Text("Identity Graph") }) }
                    item { FilterChip(selected = resultView == "SOURCES", onClick = { resultView = "SOURCES" }, label = { Text("Sources") }) }
                }
            }
            when (resultView) {
                "DATA" -> {
                    item { DataSummaryCard(r.dataPoints) }
                    if (r.dataPoints.isEmpty()) {
                        item { StatusCard("No extracted values yet", "Configure the optional web-search provider in Settings for name, e-mail and phone searches. Ghostprint will never turn an unverified search link into a fake data point.", Warning) }
                    } else {
                        items(r.dataPoints) { point -> DataPointCard(point) }
                    }
                }
                "GRAPH" -> item { IdentityGraphCard(r.graph) }
                else -> {
                    val categories = r.findings.map { it.category }.distinct()
                    if (categories.size > 1) {
                        item {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                item { FilterChip(selected = filter == null, onClick = { filter = null }, label = { Text("All") }) }
                                items(categories) { category ->
                                    FilterChip(selected = filter == category, onClick = { filter = category }, label = { Text(category.label) })
                                }
                            }
                        }
                    }
                    val visible = r.findings.filter { filter == null || it.category == filter }
                    items(visible) { finding -> FindingCard(finding) }
                }
            }
            item {
                Button(
                    onClick = onAskAi,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Violet)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Explain this scan with AI")
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
}

@Composable
private fun ExposureHeader(report: ScanReport, onShare: () -> Unit) {
    val tint = when (report.exposureLabel) {
        "HIGH" -> Danger
        "MEDIUM" -> Warning
        "LOW" -> Cyan
        else -> Good
    }
    val found = report.findings.count { it.state == FindingState.FOUND }
    val manual = report.findings.count { it.state == FindingState.MANUAL }
    Surface(shape = RoundedCornerShape(26.dp), color = Surface2.copy(alpha = .78f), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(74.dp)) {
                    CircularProgressIndicator(
                        progress = report.exposureScore / 100f,
                        modifier = Modifier.fillMaxSize(),
                        color = tint,
                        trackColor = Surface3,
                        strokeWidth = 7.dp
                    )
                    Text("${report.exposureScore}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text("Digital exposure", color = TextMuted, fontSize = 12.sp)
                    Text(report.exposureLabel, color = tint, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    Text(report.query, fontWeight = FontWeight.SemiBold)
                    Text("${report.scannedSources} sources · ${report.type.label}", color = TextMuted, fontSize = 12.sp)
                }
                IconButton(onClick = onShare) { Icon(Icons.Default.Share, contentDescription = "Share report", tint = Cyan) }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                MiniStat("Found", found.toString(), Modifier.weight(1f))
                MiniStat("Review", manual.toString(), Modifier.weight(1f))
                MiniStat("Cards", report.findings.size.toString(), Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Text("Exposure is an organizational indicator, not a verdict. Only source-backed findings contribute meaningfully to the score.", color = TextFaint, fontSize = 11.sp)
        }
    }
}

@Composable
private fun FindingCard(finding: Finding) {
    val uri = LocalUriHandler.current
    val clipboard = LocalClipboardManager.current
    var verdict by remember(finding.title, finding.url) { mutableStateOf<String?>(null) }
    var expanded by remember(finding.title) { mutableStateOf(false) }
    val tint = when (finding.level) {
        FindingLevel.HIGH -> Danger
        FindingLevel.MEDIUM -> Warning
        FindingLevel.LOW -> Cyan
        FindingLevel.INFO -> Good
    }
    val stateText = when (finding.state) {
        FindingState.FOUND -> "FOUND"
        FindingState.NOT_FOUND -> "NOT FOUND"
        FindingState.MANUAL -> "VERIFY"
        FindingState.INFO -> "INFO"
    }
    Surface(shape = RoundedCornerShape(22.dp), color = Surface2.copy(alpha = .72f), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(tint))
                Spacer(Modifier.width(9.dp))
                Text(finding.source, color = TextMuted, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Surface(shape = RoundedCornerShape(999.dp), color = tint.copy(alpha = .10f)) {
                    Text(stateText, color = tint, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
                }
            }
            Spacer(Modifier.height(9.dp))
            Text(finding.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(finding.subtitle, color = TextMuted, fontSize = 13.sp)
            if (finding.confidence > 0) {
                Spacer(Modifier.height(8.dp))
                Text("Confidence ${finding.confidence}%", color = TextFaint, fontSize = 11.sp)
            }
            finding.detail?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, fontSize = 13.sp)
            }
            if (finding.evidence.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "Hide evidence" else "Show evidence") }
                AnimatedVisibility(expanded) {
                    Column {
                        finding.evidence.forEach { Text("• $it", color = TextMuted, fontSize = 12.sp) }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                finding.url?.let { url ->
                    TextButton(onClick = { uri.openUri(url) }) {
                        Icon(Icons.Default.Link, contentDescription = null)
                        Spacer(Modifier.width(5.dp))
                        Text("Source")
                    }
                    IconButton(onClick = { clipboard.setText(AnnotatedString(url)) }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy source", tint = TextMuted)
                    }
                }
            }
            if (finding.state == FindingState.FOUND || finding.state == FindingState.MANUAL) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { verdict = "me" }) { Text("This is me") }
                    TextButton(onClick = { verdict = "not" }) { Text("Not me") }
                }
            }
            AnimatedVisibility(verdict != null) {
                Text(
                    if (verdict == "me") "Confirmed by you for this session." else "Marked as a false match for this session.",
                    color = if (verdict == "me") Good else TextMuted,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun PasswordDialog(repo: OsintRepository, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var password by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Password exposure check") },
        text = {
            Column {
                Text("Your full password never leaves the device. Ghostprint hashes it locally and sends only the first five SHA-1 characters to the Pwned Passwords range API.", color = TextMuted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; result = null },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    label = { Text("Password") }
                )
                result?.let { Spacer(Modifier.height(10.dp)); Text(it) }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (password.isBlank()) return@Button
                loading = true
                scope.launch {
                    runCatching { repo.checkPassword(password) }
                        .onSuccess { count ->
                            result = if (count > 0) "Found $count times in the breach corpus. Change it anywhere you still use it." else "No match was found in the breach corpus."
                        }
                        .onFailure { result = "Check failed: ${it.message}" }
                    loading = false
                    password = ""
                }
            }) {
                if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("Check")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun HistoryScreen(history: List<HistoryEntry>, onRescan: (String) -> Unit, onClear: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Spacer(Modifier.height(18.dp)) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("History", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("Encrypted local history, only when enabled in Settings.", color = TextMuted, fontSize = 13.sp)
                }
                if (history.isNotEmpty()) TextButton(onClick = onClear) { Text("Clear") }
            }
        }
        if (history.isEmpty()) {
            item { StatusCard("No saved scans", "History is off by default. Enable encrypted local history in Settings if you want recent scans here.", Cyan) }
        } else {
            items(history) { item ->
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Surface2.copy(alpha = .72f),
                    modifier = Modifier.fillMaxWidth().clickable { onRescan(item.query) }
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.History, contentDescription = null, tint = Cyan)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.query, fontWeight = FontWeight.SemiBold)
                            Text("${item.type.label} · ${item.exposureLabel} ${item.exposureScore}/100", color = TextMuted, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ArrowForward, contentDescription = null, tint = TextMuted)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
}

@Composable
private fun AiScreen(report: ScanReport?) {
    val context = LocalContext.current
    val prefs = remember { SecurePrefs(context) }
    val client = remember { AiBackendClient() }
    val scope = rememberCoroutineScope()
    var input by rememberSaveable { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    val backend = prefs.getString("ai_backend")
    val appToken = prefs.getSecret("ai_app_token")

    val reportContext = report?.let {
        buildString {
            append("Ghostprint self-audit scan for ${it.type.label}. Exposure: ${it.exposureLabel} (${it.exposureScore}/100).\n")
            append("Extracted source-backed/candidate data values:\n")
            it.dataPoints.take(80).forEach { d ->
                append("- ${d.type.label}: ${d.value}; source=${d.source}; confidence=${d.confidence}; candidate=${d.candidate}; url=${d.sourceUrl ?: "none"}\n")
            }
            append("Source statuses:\n")
            it.findings.take(40).forEach { f ->
                append("- ${f.category.label}/${f.source}: ${f.title}; ${f.subtitle}; state=${f.state}; confidence=${f.confidence}; source=${f.url ?: "none"}\n")
            }
        }
    }.orEmpty()

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Violet.copy(alpha = .13f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Violet)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Ghostprint AI", fontSize = 29.sp, fontWeight = FontWeight.Bold)
                Text("Security assistant for your scan results", color = TextMuted, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(14.dp))

        if (backend.isBlank()) {
            StatusCard("AI backend not connected", "Open Settings and add your HTTPS Ghostprint backend URL. Your OpenAI key stays on the backend, not in the APK.", Warning)
        } else {
            Surface(shape = RoundedCornerShape(18.dp), color = Good.copy(alpha = .08f), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(Good))
                    Spacer(Modifier.width(9.dp))
                    Text(if (report == null) "AI connected" else "AI connected · scan context attached", color = Good, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    Surface(shape = RoundedCornerShape(22.dp), color = Surface2.copy(alpha = .72f), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp)) {
                            Text("Try asking", fontWeight = FontWeight.Bold)
                            Text("“Which finding should I fix first?”\n“Explain what this breach exposed.”\n“Give me a cleanup checklist for these accounts.”", color = TextMuted, fontSize = 13.sp)
                        }
                    }
                }
            }
            items(messages) { message ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = if (message.role == "user") Arrangement.End else Arrangement.Start) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (message.role == "user") Cyan.copy(alpha = .18f) else Surface2
                    ) {
                        Text(message.text, modifier = Modifier.padding(14.dp), fontSize = 14.sp)
                    }
                }
            }
            error?.let { item { Text(it, color = Danger, fontSize = 13.sp) } }
        }
        Row(Modifier.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message Ghostprint AI") },
                shape = RoundedCornerShape(20.dp),
                singleLine = true,
                enabled = !sending,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { }),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Surface2,
                    unfocusedContainerColor = Surface2,
                    focusedIndicatorColor = Cyan,
                    unfocusedIndicatorColor = Color.Transparent
                )
            )
            Spacer(Modifier.width(8.dp))
            IconButton(
                enabled = input.isNotBlank() && backend.isNotBlank() && !sending,
                onClick = {
                    val text = input.trim()
                    messages += ChatMessage("user", text)
                    input = ""
                    sending = true
                    error = null
                    scope.launch {
                        runCatching { client.send(backend, appToken, messages.toList(), reportContext) }
                            .onSuccess { messages += ChatMessage("assistant", it) }
                            .onFailure { error = it.message ?: "AI request failed" }
                        sending = false
                    }
                }
            ) {
                if (sending) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else Icon(Icons.Default.Send, contentDescription = "Send", tint = Cyan)
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    onScreenShieldChanged: (Boolean) -> Unit,
    onHistoryChanged: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { SecurePrefs(context) }
    val historyStore = remember { HistoryStore(prefs) }
    var hibp by remember { mutableStateOf(prefs.getSecret("hibp_key")) }
    var brave by remember { mutableStateOf(prefs.getSecret("brave_key")) }
    var backend by remember { mutableStateOf(prefs.getString("ai_backend")) }
    var appToken by remember { mutableStateOf(prefs.getSecret("ai_app_token")) }
    var saveHistory by remember { mutableStateOf(prefs.getBoolean("save_history", false)) }
    var screenShield by remember { mutableStateOf(prefs.getBoolean("screen_shield", false)) }
    var saved by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(Modifier.height(18.dp)) }
        item {
            Text("Settings", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("Security-sensitive values are stored with Android Keystore encryption.", color = TextMuted, fontSize = 13.sp)
        }
        item {
            SettingsCard("Have I Been Pwned", "Optional. Required for account breach lookups.") {
                OutlinedTextField(
                    value = hibp,
                    onValueChange = { hibp = it; saved = false },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("HIBP API key") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
            }
        }
        item {
            SettingsCard("Public web extraction", "Optional. A Brave Search API key lets Ghostprint return actual result titles, snippets and source URLs for name, e-mail and phone self-audits instead of only opening manual search links.") {
                OutlinedTextField(
                    value = brave,
                    onValueChange = { brave = it; saved = false },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Brave Search API key") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
            }
        }
        item {
            SettingsCard("Ghostprint AI backend", "The OpenAI API key stays on your server and is never packaged into the Android app.") {
                OutlinedTextField(
                    value = backend,
                    onValueChange = { backend = it; saved = false },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("https://your-backend.example") },
                    singleLine = true
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = appToken,
                    onValueChange = { appToken = it; saved = false },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Backend app token (optional)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
            }
        }
        item {
            SettingsCard("Privacy", "Keep sensitive scan data under your control.") {
                SettingSwitch(
                    icon = Icons.Default.History,
                    title = "Encrypted scan history",
                    subtitle = "Off by default. Stores only recent query summaries locally.",
                    checked = saveHistory,
                    onCheckedChange = {
                        saveHistory = it
                        prefs.putBoolean("save_history", it)
                        if (!it) historyStore.clear()
                        onHistoryChanged()
                    }
                )
                Spacer(Modifier.height(10.dp))
                SettingSwitch(
                    icon = Icons.Default.Lock,
                    title = "Screenshot shield",
                    subtitle = "Blocks screenshots and screen recording while Ghostprint is open.",
                    checked = screenShield,
                    onCheckedChange = {
                        screenShield = it
                        prefs.putBoolean("screen_shield", it)
                        onScreenShieldChanged(it)
                    }
                )
            }
        }
        item {
            Button(
                onClick = {
                    prefs.putSecret("hibp_key", hibp.trim())
                    prefs.putSecret("brave_key", brave.trim())
                    prefs.putString("ai_backend", backend.trim())
                    prefs.putSecret("ai_app_token", appToken.trim())
                    saved = true
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp)
            ) {
                if (saved) Icon(Icons.Default.Check, contentDescription = null)
                Text(if (saved) "  Saved" else "Save settings")
            }
        }
        item {
            StatusCard(
                "Self-audit boundary",
                "Ghostprint is designed for your own identifiers or authorized audits. It does not scrape private databases, bypass logins, or display stolen plaintext passwords.",
                Cyan
            )
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
}

@Composable
private fun SettingSwitch(icon: ImageVector, title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Icon(icon, contentDescription = null, tint = Cyan)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = TextMuted, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SettingsCard(title: String, subtitle: String, content: @Composable () -> Unit) {
    Surface(shape = RoundedCornerShape(24.dp), color = Surface2.copy(alpha = .72f), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(subtitle, color = TextMuted, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
private fun StatusCard(title: String, text: String, tint: Color) {
    Surface(shape = RoundedCornerShape(20.dp), color = tint.copy(alpha = .08f), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp)) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(tint).align(Alignment.CenterVertically))
            Spacer(Modifier.width(11.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(text, color = TextMuted, fontSize = 13.sp)
            }
        }
    }
}

private fun shareReport(context: android.content.Context, report: ScanReport) {
    val text = buildString {
        appendLine("Ghostprint self-audit")
        appendLine("Query: ${report.query}")
        appendLine("Type: ${report.type.label}")
        appendLine("Exposure: ${report.exposureLabel} (${report.exposureScore}/100)")
        appendLine("Sources: ${report.scannedSources}")
        appendLine()
        appendLine("EXTRACTED DATA")
        report.dataPoints.forEach { d ->
            appendLine("[${if (d.candidate) "VERIFY" else "SOURCE-BACKED"}] ${d.type.label}: ${d.value}")
            appendLine("Source: ${d.source} · confidence ${d.confidence}%")
            d.sourceUrl?.let { appendLine(it) }
            d.evidence?.let { appendLine("Evidence: $it") }
            appendLine()
        }
        appendLine("SOURCE STATUS")
        report.findings.forEach { f ->
            appendLine("[${f.state}] ${f.source} · ${f.title}")
            appendLine(f.subtitle)
            f.url?.let { appendLine(it) }
            appendLine()
        }
    }
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "Ghostprint self-audit")
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, "Share Ghostprint report"))
}
