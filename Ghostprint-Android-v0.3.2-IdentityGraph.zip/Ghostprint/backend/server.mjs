import http from "node:http";
import OpenAI from "openai";

const apiKey = process.env.OPENAI_API_KEY;
if (!apiKey) throw new Error("OPENAI_API_KEY is required");

const client = new OpenAI({ apiKey });
const port = Number(process.env.PORT || 8787);
const model = process.env.OPENAI_MODEL || "gpt-5.6";
const appToken = process.env.GHOSTPRINT_APP_TOKEN || "";
const perMinute = Math.max(1, Number(process.env.RATE_LIMIT_PER_MINUTE || 30));
const buckets = new Map();

const server = http.createServer(async (req, res) => {
  securityHeaders(res);

  if (req.method === "GET" && req.url === "/health") {
    return json(res, 200, { ok: true, model });
  }

  if (req.method !== "POST" || req.url !== "/chat") {
    return json(res, 404, { error: "Not found" });
  }

  if (appToken) {
    const auth = req.headers.authorization || "";
    if (auth !== `Bearer ${appToken}`) return json(res, 401, { error: "Unauthorized" });
  }

  const identity = req.socket.remoteAddress || "unknown";
  if (!takeRateLimit(identity)) return json(res, 429, { error: "Too many requests" });

  try {
    const raw = await readBody(req);
    const body = JSON.parse(raw || "{}");
    const history = Array.isArray(body.history) ? body.history.slice(-20) : [];
    const context = typeof body.context === "string" ? body.context.slice(0, 24000) : "";

    const input = history
      .filter(m => ["user", "assistant"].includes(m.role) && typeof m.text === "string")
      .map(m => ({ role: m.role, content: m.text.slice(0, 12000) }));

    if (!input.length) return json(res, 400, { error: "No chat message supplied" });

    const response = await client.responses.create({
      model,
      store: false,
      instructions: [
        "You are Ghostprint AI, a defensive assistant for a user's own digital-footprint and account-security audit.",
        "Treat scan findings as evidence with uncertainty, not as proof of identity unless the user confirms it.",
        "Never invent addresses, accounts, breaches, identities, or leaked credentials.",
        "Do not help locate private individuals, bypass access controls, steal credentials, or aggregate sensitive personal data for targeting.",
        "Prioritize defensive actions: password changes, MFA, privacy settings, account recovery, data-removal requests, and source verification.",
        context ? `Current self-audit scan context:\n${context}` : "No scan context was provided."
      ].join("\n"),
      input
    });

    return json(res, 200, { text: response.output_text || "" });
  } catch (error) {
    const status = Number(error?.status || 500);
    const safeStatus = status >= 400 && status < 600 ? status : 500;
    const message = error?.message || "Unknown server error";
    return json(res, safeStatus, { error: message });
  }
});

server.listen(port, "0.0.0.0", () => {
  console.log(`Ghostprint backend listening on :${port} with ${model}`);
});

function takeRateLimit(key) {
  const now = Date.now();
  const minute = 60_000;
  const recent = (buckets.get(key) || []).filter(t => now - t < minute);
  if (recent.length >= perMinute) return false;
  recent.push(now);
  buckets.set(key, recent);
  return true;
}

function securityHeaders(res) {
  res.setHeader("x-content-type-options", "nosniff");
  res.setHeader("referrer-policy", "no-referrer");
  res.setHeader("cache-control", "no-store");
}

function json(res, status, payload) {
  res.writeHead(status, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", chunk => {
      data += chunk;
      if (data.length > 1_000_000) {
        req.destroy();
        reject(new Error("Request too large"));
      }
    });
    req.on("end", () => resolve(data));
    req.on("error", reject);
  });
}
