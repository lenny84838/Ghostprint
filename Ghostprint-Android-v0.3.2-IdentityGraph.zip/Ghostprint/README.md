# Ghostprint 0.3

Ghostprint is a private Android self-audit app for reviewing your own public digital footprint. It is built with Kotlin + Jetpack Compose and uses an evidence-first model: when a source returns data, Ghostprint shows the actual value, what kind of data it is, where it came from, and how confident the match is.

## What changed in 0.3

### Extracted Data view
A scan no longer stops at “found”. It can return typed data points such as:

- names and display names
- usernames
- public profile URLs
- public bios
- public websites
- company / organisation fields
- public locations
- address candidates found in indexed snippets
- e-mail candidates
- phone candidates
- breach names and dates
- exact HIBP data classes reported as exposed
- public account metadata and metrics
- web-result titles, snippets and original URLs

Every value keeps its original source URL and a confidence level. Ambiguous values are explicitly marked **VERIFY** instead of being presented as fact.

### Identity Graph
The new graph creates nodes for the searched identity, accounts, contact details, locations, breach data and sources. Edges show which value came from which source. The graph supports pan and pinch-to-zoom.

### Better source extraction
- GitHub public user API: username, display name, bio, company, location, website, social username, account date and public metrics.
- Reddit public profile API: username, profile description and public metrics where available.
- Gravatar: public profile fields tied to the e-mail hash.
- Have I Been Pwned: breach metadata plus every returned `DataClasses` category. HIBP does not provide stolen plaintext values or passwords, so Ghostprint does not invent or claim them.
- Public profile pages: Open Graph/title/description metadata when the site allows access.
- Optional Brave Search API: actual web result titles, snippets and source URLs for name, e-mail, phone and general searches. Ghostprint extracts e-mail/phone/address/location candidates from those returned snippets and marks ambiguous ones for verification.

## Setup

1. Open the project in Android Studio (JDK 17).
2. Build the `app` module, or push to GitHub and run the included **Build Ghostprint APK** workflow.
3. In Ghostprint → Settings:
   - Optional: add a Have I Been Pwned API key for e-mail breach lookups.
   - Optional: add a Brave Search API key for in-app public web-result extraction.
   - Optional: configure the Ghostprint AI backend from `backend/`.

Sensitive API keys saved in the Android app are encrypted with a key stored in Android Keystore. The OpenAI key is intentionally not stored in the APK; it belongs on the provided backend.

## Accuracy model

Ghostprint distinguishes:

- **SOURCE-BACKED**: a public API or endpoint returned the value directly.
- **VERIFY**: the value was found near the searched identifier, but identity linkage is not proven.
- **NOT FOUND**: the queried public endpoint returned no profile at scan time.
- **MANUAL**: the source blocked, rate-limited or could not be verified automatically.

A public name search can match another person with the same name. Address and contact candidates therefore stay marked for verification until you confirm them.

## Scope and privacy

Ghostprint is designed for your own identifiers or audits you are authorised to perform. The UI requires that confirmation before a scan. It does not bypass authentication, scrape private databases, recover stolen plaintext passwords, or claim that a candidate value belongs to you without source evidence.

No OSINT tool can guarantee that it has indexed “the entire internet”. Ghostprint instead aims to display all values returned by the sources you have configured, without hiding the raw source context behind a vague “found” badge.
