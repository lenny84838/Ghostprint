# Ghostprint security notes

- Do not hard-code OpenAI or HIBP API keys in source control.
- The Android app encrypts configured secrets with a key held by Android Keystore.
- The OpenAI API key belongs only on the backend.
- If the backend is reachable from the public internet, configure `GHOSTPRINT_APP_TOKEN`, HTTPS, real authentication if multiple users are involved, and production rate limiting.
- Scan history is disabled by default. When enabled, the history JSON is AES-GCM encrypted locally.
- The screenshot shield can be enabled from Settings.
- A public-source match is not proof that an account belongs to the person being searched. Verify the original source.
